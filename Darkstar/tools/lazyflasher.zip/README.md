# Disables Verity and Forceencrypt
Heavily based on previous work by topjohnwu and jcadduono
